// Lab 09 - Task 03: Stack using array (push, pop, search, overflow/underflow)
#include <iostream>
using namespace std;

const int MAX=5;
int stack[MAX];
int top=-1;

bool isEmpty()
{
    return top==-1;
}

bool isFull()
{
    return top==MAX-1;
}

void push(int x)
{
    if(isFull())
    {
        cout<<"Stack Overflow"<<endl;
    }
    else
    {
        top++;
        stack[top]=x;
    }
}

void pop()
{
    if(isEmpty())
    {
        cout<<"Stack Underflow"<<endl;
    }
    else
    {
        cout<<"Popped: "<<stack[top]<<endl;
        top--;
    }
}

int search(int x)
{
    int steps=1;

    for(int i=top;i>=0;i--)
    {
        if(stack[i]==x)
        {
            return steps;
        }
        steps++;
    }

    return -1;
}

int main()
{
    int value;

    cout<<"Enter five integers:"<<endl;

    for(int i=0;i<MAX;i++)
    {
        cin>>value;
        push(value);
    }

    cout<<"Trying to push sixth value:"<<endl;
    push(60);

    cout<<"Enter a value that is present:"<<endl;
    cin>>value;
    cout<<"Search result: "<<search(value)<<endl;

    cout<<"Enter a value that is absent:"<<endl;
    cin>>value;
    cout<<"Search result: "<<search(value)<<endl;

    cout<<"Popping all elements:"<<endl;

    while(!isEmpty())
    {
        pop();
    }

    cout<<"Trying to pop again:"<<endl;
    pop();

    return 0;
}
