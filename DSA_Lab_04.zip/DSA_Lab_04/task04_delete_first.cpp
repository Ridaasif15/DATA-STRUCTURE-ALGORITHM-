// Task 04: Delete the first element from: 10, 20, 30, 40, 50
#include <iostream>
using namespace std;

int main()
{
    int arr[100] = {10, 20, 30, 40, 50};
    int n = 5;

    for(int i = 0; i < n - 1; i++)
    {
        arr[i] = arr[i + 1];
    }

    n--;

    cout << "Array: ";
    for(int i = 0; i < n; i++)
    {
        cout << arr[i] << " ";
    }

    return 0;
}
