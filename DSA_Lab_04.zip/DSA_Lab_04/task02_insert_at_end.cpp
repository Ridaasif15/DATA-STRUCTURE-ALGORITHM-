// Task 02: Insert 60 at the end of the array: 10, 20, 30, 40, 50
#include <iostream>
using namespace std;

int main()
{
    int arr[100] = {10, 20, 30, 40, 50};
    int n = 5;
    int value = 60;

    arr[n] = value;
    n++;

    cout << "Array: ";
    for(int i = 0; i < n; i++)
    {
        cout << arr[i] << " ";
    }

    return 0;
}
