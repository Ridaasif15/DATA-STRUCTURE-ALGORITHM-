// Task 06: Delete the element at index 2 from: 10, 20, 30, 40, 50
#include <iostream>
using namespace std;

int main()
{
    int arr[100] = {10, 20, 30, 40, 50};
    int n = 5;
    int position = 2;

    for(int i = position; i < n - 1; i++)
    {
        arr[i] = arr[i + 1];
    }

    n--;

    cout << "Array: ";
    for(int i = 0; i < n; i++)
    {
        cout << arr[i] << " ";
    }

    return 0;
}
