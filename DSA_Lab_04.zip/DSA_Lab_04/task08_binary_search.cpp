// Task 08: Use Binary Search to find 40 in the sorted array: 10, 20, 30, 40, 50
#include <iostream>
using namespace std;

int main()
{
    int arr[] = {10, 20, 30, 40, 50};
    int n = 5;
    int value = 40;
    int position = -1;

    int low = 0;
    int high = n - 1;

    while(low <= high)
    {
        int mid = (low + high) / 2;

        if(arr[mid] == value)
        {
            position = mid;
            break;
        }
        else if(arr[mid] < value)
        {
            low = mid + 1;
        }
        else
        {
            high = mid - 1;
        }
    }

    if(position != -1)
    {
        cout << "Value found at index " << position;
    }
    else
    {
        cout << "Value not found";
    }

    return 0;
}
